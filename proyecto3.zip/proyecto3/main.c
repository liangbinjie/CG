#include "config/config.h"
#include "object/object.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "utils/avs.h"

Color **create_buffer(Config config) {
    Color **framebuffer = (Color **)malloc(config.height * sizeof(Color *));

    for (int i = 0; i < config.height; i++) {
        framebuffer[i] = (Color *)malloc(config.width * sizeof(Color));
    }
    return framebuffer;
}

void fill_buffer(Color **framebuffer, Config config) {
    Color color;
    Position ray;
    
    double Xw, Yw, Zw, L;
    double Xe = config.eye.x;
    double Ye = config.eye.y;
    double Ze = config.eye.z;
    
    for (int i = 0; i < config.width; i++) {
        for (int j = 0; j < config.height; j++) {
            
            Xw = ((i+0.5)/config.width) * 
                 (config.window.xmax - config.window.xmin) +
                 config.window.xmin;
            Yw = ((j+0.5)/config.height) * 
                 (config.window.ymax - config.window.ymin) +
                 config.window.ymin;
            Zw = 0.0;
            
            L = sqrt((Xw-Xe)*(Xw-Xe) + 
                     (Yw-Ye)*(Yw-Ye) + 
                     (Zw-Ze)*(Zw-Ze));
            
            ray.x = (Xw-Xe)/L;
            ray.y = (Yw-Ye)/L;
            ray.z = (Zw-Ze)/L;
	    
	    color = de_que_color(config.eye, ray, config);
	    
            framebuffer[j][i] = color;

        }
    }
}

void free_buffer(Color **framebuffer, Config config) {
    for (int i = 0; i < config.height; i++) {
        free(framebuffer[i]);
    }

    free(framebuffer);
}

void load_objects(Config config) {
    printf("Objects loaded:\n");
    Object *current = config.objects;
    while (current != NULL) {
        if (current->type == SPHERE) {
            Sphere *sphere_data = (Sphere *)current->data;
            
        } else if (current->type == POLYGON) {
            Polygon *polygon = (Polygon *)current->data;
            printf("Polygon with %d vertices, normal (%.3f, %.3f, %.3f)\n", 
            polygon->vertex_count, polygon->normal.x, polygon->normal.y, polygon->normal.z);
        }
        current = current->next;
    }
}

int main(int argc, char **argv) {
    Config config;
    Color **framebuffer;
    char avs_filename[sizeof(config.output_name) + 5];

    if (load_config(&config) != 0) {
        fprintf(stderr, "ERROR: Failed to load config file.\n");
        return 1;
    }
    
    framebuffer = create_buffer(config);
    
    fill_buffer(framebuffer, config);

    if (snprintf(avs_filename, sizeof(avs_filename), "%s.avs",
                 config.output_name) < 0 ||
        save_avs(avs_filename, framebuffer, config.width, config.height) != 0) {
        fprintf(stderr, "ERROR: Failed to save AVS file.\n");
        free_buffer(framebuffer, config);
        free_objects(config.objects);
        return 1;
    }

    if (display_avs(avs_filename) != 0) {
        fprintf(stderr, "ERROR: Could not display AVS with ImageMagick.\n");
        free_buffer(framebuffer, config);
        free_objects(config.objects);
        return 1;
    }
    
    free_buffer(framebuffer, config);
    
    free_objects(config.objects);

    return 0;
}
